from cribl_python_api_wrapper.groups import *


def groups_testing(base_url, cribl_auth_token, worker_group=None):
    # print(f'Testing deploy_commit()...')
    # response = deploy_commit(base_url=base_url, cribl_auth_token=cribl_auth_token, version="rf-123",
    #                          worker_group=worker_group)
    # print(f"Response: %s" % response.json())
    pass
